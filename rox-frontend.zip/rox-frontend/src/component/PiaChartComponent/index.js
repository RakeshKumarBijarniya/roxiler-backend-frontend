import { PieChart, Pie, Legend, Cell, ResponsiveContainer } from "recharts";
import "./index.css";

const PiaChartComponent = (props) => {
  const { itemsArray } = props;
  let mansCloth = 0;
  let womensCloth = 0;
  let jewelery = 0;
  let electronic = 0;

  itemsArray.map((item) => {
    if (item.category === "men's clothing") {
      return (mansCloth += 1);
    } else if (item.category === "women's clothing") {
      return (womensCloth += 1);
    } else if (item.category === "jewelery") {
      return (jewelery += 1);
    } else if (item.category === "electronics") {
      return (electronic += 1);
    }
  });

  const data = [
    {
      count: mansCloth,
      category: "men's clothing",
    },
    {
      count: womensCloth,
      category: "women's clothing",
    },
    {
      count: jewelery,
      category: "jewelery",
    },
    {
      count: electronic,
      category: "electronics",
    },
  ];

  return (
    <div className="pie-container ">
      <ResponsiveContainer width="50%" height={300}>
        <PieChart>
          <Pie
            cx="70%"
            cy="40%"
            data={data}
            startAngle={0}
            endAngle={360}
            innerRadius="40%"
            outerRadius="70%"
            dataKey="count"
          >
            <Cell name="men's clothing" fill="#fecba6" />
            <Cell name="women's clothing" fill="#b3d23f" />
            <Cell name="jewelery" fill="#a44c9e" />
            <Cell name="electronics" fill="#ade" />
          </Pie>
          <Legend
            iconType="circle"
            layout="vertical"
            verticalAlign="middle"
            align="right"
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default PiaChartComponent;
