const TaskList = (props) => {
  const { itemsArray } = props;

  let totalSale = 0;
  let totalItemSold = 0;
  let totalNotSoldItem = 0;

  itemsArray.map((items, key) => {
    totalSale += Math.floor(items.price);
    return totalSale;
  });

  itemsArray.map((items, key) => {
    if (items.sold) {
      totalItemSold += 1;
    } else {
      totalNotSoldItem += 1;
      return totalNotSoldItem;
    }
    return totalItemSold;
  });

  return (
    <div className="result-container">
      <p> Total Sale {totalSale}</p>
      <p> Total Sold Item {totalItemSold}</p>
      <p> Total Not Sold Item {totalNotSoldItem}</p>
    </div>
  );
};

export default TaskList;
