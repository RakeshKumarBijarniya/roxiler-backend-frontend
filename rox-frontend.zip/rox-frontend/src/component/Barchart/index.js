import {
    ResponsiveContainer,
    BarChart,
    Bar,
    Legend,
    XAxis,
    YAxis,
  } from "recharts";
  
  const Barchart = (props) => {
    const { itemsArray } = props;
  
    let price_100 = 0;
    let price_200 = 0;
    let price_300 = 0;
    let price_400 = 0;
    let price_500 = 0;
    let price_600 = 0;
    let price_700 = 0;
    let price_800 = 0;
    let price_900 = 0;
    let price_900_above = 0;
    itemsArray.map((item) => {
      // console.log(item);
      if (item.price < 100) {
        return (price_100 += 1);
      } else if (item.price > 100 && item.price < 200) {
        return (price_200 += 1);
      } else if (item.price > 200 && item.price < 300) {
        return (price_300 += 1);
      } else if (item.price > 300 && item.price < 400) {
        return (price_400 += 1);
      } else if (item.price > 400 && item.price < 500) {
        return (price_500 += 1);
      } else if (item.price > 500 && item.price < 600) {
        return (price_600 += 1);
      } else if (item.price > 600 && item.price < 700) {
        return (price_700 += 1);
      } else if (item.price > 700 && item.price < 800) {
        return (price_800 += 1);
      } else if (item.price > 800 && item.price < 900) {
        return (price_900 += 1);
      } else if (item.price > 900) {
        return (price_900_above += 1);
      }
    });
  
    const priceRange = [
      {
        price: "0-100",
        range: 0,
        item: price_100,
      },
      {
        price: "100-200",
        range: 2,
        item: price_200,
      },
      {
        price: "200-300",
        range: 4,
        item: price_300,
      },
      {
        price: "300-400",
        range: 6,
        item: price_400,
      },
      {
        price: "400-500",
        range: 8,
        item: price_500,
      },
      {
        price: "500-600",
        range: 10,
        item: price_600,
      },
      {
        price: "600-700",
        range: 12,
        item: price_700,
      },
      {
        price: "700-800",
        range: 14,
        item: price_800,
      },
      {
        price: "800-900",
        range: 16,
        item: price_900,
      },
      {
        price: "900-above",
        range: 18,
        item: price_900_above,
      },
    ];
  
    return (
      <div>
        <ResponsiveContainer width="80%" aspect={3}>
          <BarChart data={priceRange} width={500} height={500}>
            <XAxis
              dataKey="price"
              tick={{
                stroke: "gray",
                strokeWidth: 1,
              }}
            />
            <YAxis
              dataKey="range"
              tick={{
                stroke: "gray",
                strokeWidth: 0,
              }}
            />
            <Bar dataKey="item" name="price" fill="#1f77b4" barSize="20%" />
            <Legend
              wrapperStyle={{
                padding: 30,
              }}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    );
  };
  
  export default Barchart;
  