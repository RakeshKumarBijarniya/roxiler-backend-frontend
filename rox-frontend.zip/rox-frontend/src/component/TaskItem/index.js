const TaskItem = (props) => {
    const { items } = props;
    const { id, title, price, description, image, sold } = items;
    return (
      <tr>
        <td className="p-2">{id}</td>
        <td className="p-2">{title.slice(0, 30)}</td>
        <td className="p-2">{Math.floor(price)}</td>
        <td className="p-2">{description.slice(0, 45)}...</td>
        <td className="p-2">{image}</td>
        <td className="p-2">{sold}</td>
      </tr>
    );
  };
  
  export default TaskItem;
  