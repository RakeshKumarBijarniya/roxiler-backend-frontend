import { Component } from "react";

import { Table } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

import TaskList from "../TaskList";
import TaskItem from "../TaskItem";
import Barchart from "../Barchart";
import PiaChartComponent from "../PiaChartComponent";

import "./index.css";

const monthsOptions = [
  { label: "Select Months", value: "00" },
  { label: "January", value: "01" },
  { label: "February", value: "02" },
  { label: "March", value: "03" },
  { label: "April", value: "04" },
  { label: "May", value: "05" },
  { label: "June", value: "06" },
  { label: "July", value: "07" },
  { label: "August", value: "08" },
  { label: "September", value: "09" },
  { label: "October", value: "10" },
  { label: "November", value: "11" },
  { label: "December", value: "12" },
];

class Home extends Component {
  state = {
    itemsArray: [],
    offset: 0,
    searchInput: "",
    selectedMoths: "",
  };

  componentDidMount() {
    this.getItemsDetails();
  }

  getItemsDetails = async () => {
    const { selectedMoths } = this.state;
    const monthValue = selectedMoths;
    if (monthValue === "00") {
      const apiUrl = `http://localhost:8000/tasksMonth`;
      const response = await fetch(apiUrl);
      const data = await response.json();
      this.setState({ itemsArray: data });
    } else {
      const apiUrl = `http://localhost:8000/tasksMonth/${monthValue}`;
      const response = await fetch(apiUrl);
      const data = await response.json();
      this.setState({ itemsArray: data });
      console.log(data);
    }
  };

  searchValue = async (e) => {
    this.setState({ searchInput: e.target.value });
  };

  changeMonth = async (e) => {
    await this.setState({ selectedMoths: e.target.value });
    this.getItemsDetails();
  };

  nextPage = () => {
    const { offset, itemsArray } = this.state;
    if (offset < itemsArray.length - 10) {
      this.setState((prevState) => {
        return { offset: prevState.offset + 10 };
      });
    }
  };

  prePage = () => {
    const { offset } = this.state;
    if (offset >= 1) {
      this.setState((prevState) => {
        return { offset: prevState.offset - 10 };
      });
    }
  };

  render() {
    const { itemsArray, offset, searchInput, selectedMoths } = this.state;

    const searchResult = itemsArray.filter((eachItem) =>
      eachItem.title.toLowerCase().includes(searchInput)
    );

    return (
      <div className="app-container">
        <div className="top-container">
          <h1 className="heading">Transaction Dashboard</h1>
        </div>
        <div className="input-container">
          <div className="search-container">
            <input
              type="text"
              placeholder="Search Transaction"
              onChange={this.searchValue}
              value={searchInput}
            />
          </div>
          <div className="choose-months-container">
            <select onChange={this.changeMonth} value={selectedMoths}>
              {monthsOptions.map((month) => {
                return <option value={month.value}>{month.label}</option>;
              })}
            </select>
          </div>
        </div>

        <Table striped bordered hover className="bg-warning">
          <tr>
            <th className="p-2">id</th>
            <th className="p-2">title</th>
            <th className="p-2">price</th>
            <th className="p-2">description</th>
            <th className="p-2">image</th>
            <th className="p-2">sold</th>
          </tr>
          {searchResult.slice(offset, offset + 10).map((item) => (
            <TaskItem items={item} key={item.id} />
          ))}
        </Table>
        <div className="button-container">
          <button className="btn btn-primary m-4" onClick={this.nextPage}>
            next
          </button>
          <button className="btn btn-primary m-4" onClick={this.prePage}>
            Previous
          </button>
        </div>

        <TaskList
          selectedMoths={selectedMoths}
          key={selectedMoths}
          itemsArray={itemsArray}
        />
        <PiaChartComponent itemsArray={itemsArray} key={itemsArray.price} />

        <Barchart itemsArray={itemsArray} key={itemsArray.price} />
      </div>
    );
  }
}
export default Home;
