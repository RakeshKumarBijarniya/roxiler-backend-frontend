import Home from "./component/Home";
import "./App.css";

function App() {
  return (
    <div>
      <Home />
      <h1>Hii</h1>
    </div>
  );
}

export default App;
